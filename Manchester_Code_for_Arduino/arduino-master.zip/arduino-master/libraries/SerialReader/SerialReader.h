#ifndef SERIALREAD_H
#define SERIALREAD_H

class SerialReader
{
  public:
    int readString(char*, int);
};

#endif

