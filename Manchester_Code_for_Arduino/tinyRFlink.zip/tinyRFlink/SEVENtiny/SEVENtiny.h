/*
This is a general purpose 4 digit 7 segment LED display.

It uses two 16 bit serial input constant-current LED
drivers with four 7 segment displays.

It uses 3 digital pins from the arduino.

The code is all in a class which has 4 functions:

SEVENtiny.displayI(int number)
This displays numbers in the range -999 to 9999.
The number is left justified. If it is not in
the range "EEEE" will be displayed.

SEVEN.displayF(float number)
This displays numbers in the range -99.9 to 999.9.
One decimal point is displayed.
The number is left justified. If it is not in
the range "EEEE" will be displayed.

SEVENtiny.displayP(long picture)
Picture is 32 bits which map to each segment.

SEVEN.displayA(long origional,unsigned char addition)
This is designed to be used with displayI or displayF.
It adds the right hand character to the display.

The connections and the 7 segment display I use give
the following bit connection diagram.   

                D1
           ____________
           
          |            |
          |            |
       D3 |            | D0
          |            |
          |            |
                D2
           ____________

           
          |            |
          |            |
       D4 |            | D6
          |            |
          |            |
           ____________
                           __
                D5        |dp| D7
                           --  

 
To display a "3" the bits are:

D7 D6 D5 D4 / D3 D2 D1 D0
0  1  1  0  / 0  1  1  1  = 0x67      

*/
#ifndef SEVENtiny_h
#define SEVENtiny_h

#define setupD0D1D2 DDRB |= 0x07  //data 0,1,2 to outputs
#define latchpinLOW PORTB &= ~0x02;  //set latch pin 1 to low
#define latchpinHIGH PORTB |= 0x02;  //set latch pin 1 to high
#define clockpinLOW PORTB &= ~0x04;  //set clock pin 2 to low
#define clockpinHIGH PORTB |= 0x04;  //set clock pin 2 to high
#define datapinLOW PORTB &= ~0x01;  //set data pin 0 to low
#define datapinHIGH PORTB |= 0x01;  //set data pin 0 to high
const unsigned char N[] = {0x7b,0x41,0x37,0x67,0x4d,0x6e,0x7e,0x43,0x7f,0x4f};
//the 7 segment display codes for each digit "0" ......."9"
const unsigned long error = 0x3e3e3e3e;  //the error display message EEEE
const unsigned long minussign = 0x04000000;   //the display minus sign
const unsigned long decpoint = 0x80000000;  //decimal point far left place

#include "WProgram.h"

class SEVENtinyclass
{
public:
unsigned long displayI(int number);  //display number from -999 to 9999
unsigned long displayF(float number);  //display number from - 99.9 to 999.9
void displayP(long picture);  //display the picture passed
void displayA(long origional,unsigned char addition); //add last character onto the display 

private:
unsigned long assignchar(int number); // get the pattern for number

};//end of class SEVENclass

 extern SEVENtinyclass SEVENtiny;

#endif
