# Arduino_RF433_AES-256
Arduino example of RF-433MHz communication with Manchester encoding and AES-256 secure encryption
